package com.example.demo.model;


import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(notes = "id", example = "1", required = true)
    private Long id;

    @ApiModelProperty(notes = "userName", example = "Cool_Ivan2014", required = true)
    private String userName;


    @ApiModelProperty(notes = "firstName", example = "Ivan", required = true)
    @Column(name = "first_name")
    private String firstName;

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getUserName() {
        return userName;
    }

    public Long getId() {
        return id;
    }

}
