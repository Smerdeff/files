package com.example.demo.controller;

import com.example.demo.config.SwaggerConfiguration;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.List;
import java.util.Optional;


//аннотация для обозначения REST контроллера
@RestController
// аннотация для обозначение обрабатываемого url
// будет обрабатывает все отправленные запросы по /api/user/...
@RequestMapping("/api/users")
@Api(tags = {SwaggerConfiguration.USERS_TAG})
public class UserController {

    //для взаимодействия с сущностью user импортируем UserRepository
    @Autowired
    private UserRepository userRepository;

    // @GetMapping обозначает что будет обрабатываться get запрос
    // getUsers() - возвращает список всех пользователей записанных в бд, который мы получаем с помощью метода репозитория  findAll()
    @GetMapping("/")
    public List<User> getUsers() {
        return this.userRepository.findAll();
    }


    // getUser получение конкретного пользователя по его id
    // с помощью @PathVariable мы получаем из нашего url переменную id
    @GetMapping("/{id}")
    public User getUser(@PathVariable Long id) {
        Optional<User> user = userRepository.findById(id);
        return user.get();
    }

    // addUser - добавление пользователя в бд
    // @RequestBody - обрабатывает тело запроса и достает только те данные, которые мы указываем.
    // в данном случае в качестве типа получамых данных указана модель User, следовательно
    // обрабатываться будут только поля с подходящими названиями к полям модели User
    @PostMapping("/")
    public User addUser(@RequestBody User newUser) {
        return userRepository.save(newUser);
    }

}
