package com.example.demo.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerConfiguration {

    public static final String BOOK_TAG = "book service";
    public static final String GREETING_TAG = "greeting service";
    public static final String USERS_TAG = "users service";

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.example.demo.controller"))
                .paths(PathSelectors.any())
                .build()
                .tags(
                        new Tag(BOOK_TAG, "the book API with description api tag"),
                        new Tag(USERS_TAG, "the users API with description api tag"),
                        new Tag(GREETING_TAG,"the greeting API with description api tag" ));
    }

}