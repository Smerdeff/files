package com.example.demo.repository;

import com.example.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;


public interface UserRepository extends JpaRepository<User, Long> {
    /*
    @Query("SELECT u FROM User u WHERE u.status = 1")
    List<User> findAllActiveUsers();

    @Query(value = "SELECT * FROM Users u WHERE u.status = :status and u.name = :name",
            nativeQuery = true)
    List<User> findUserByStatusAndNameNamedParamsNative(
            @Param("status") Integer status, @Param("name") String name);
*/
}

